const STORAGE_KEY = "interiorReferenceClips";

const clipCurrentTabButton = document.getElementById("clipCurrentTab");
const clearAllButton = document.getElementById("clearAll");
const clipList = document.getElementById("clipList");
const clipCount = document.getElementById("clipCount");
const statusMessage = document.getElementById("statusMessage");
const searchInput = document.getElementById("searchInput");
const template = document.getElementById("clipItemTemplate");

let clips = [];
let searchQuery = "";

function setStatus(message) {
  statusMessage.textContent = message;
}

function createId() {
  if (typeof crypto !== "undefined" && crypto.randomUUID) {
    return crypto.randomUUID();
  }

  return `clip-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function slugifyFileName(value) {
  const cleaned = (value || "interior-reference")
    .replace(/[<>:"/\\|?*\u0000-\u001f]/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  return cleaned || "interior-reference";
}

function getHostname(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return "";
  }
}

function cleanText(value) {
  return (value || "").replace(/\s+/g, " ").trim();
}

function normalizeTextForCompare(value) {
  return cleanText(value)
    .toLowerCase()
    .replace(/https?:\/\/|www\./g, "")
    .replace(/[^a-z0-9\uac00-\ud7a3]+/g, "");
}

function uniqueNonEmpty(values) {
  return Array.from(new Set((values || []).map((value) => cleanText(value)).filter(Boolean)));
}

async function saveClips() {
  await chrome.storage.local.set({ [STORAGE_KEY]: clips });
}

async function loadClips() {
  const stored = await chrome.storage.local.get(STORAGE_KEY);
  clips = Array.isArray(stored[STORAGE_KEY]) ? stored[STORAGE_KEY] : [];
  render();
}

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

function updateClip(id, patch) {
  clips = clips.map((clip) => (clip.id === id ? { ...clip, ...patch } : clip));
  void saveClips();
  render();
}

function removeClip(id) {
  clips = clips.filter((clip) => clip.id !== id);
  void saveClips();
  render();
  setStatus("클립을 삭제했습니다.");
}

async function downloadImageForClip(clip) {
  if (!clip.thumbnail) {
    setStatus("저장할 대표이미지가 없습니다.");
    return;
  }

  const baseName = slugifyFileName(clip.title || "reference-image");
  const extensionMatch = clip.thumbnail.match(/\.(jpg|jpeg|png|webp|gif)(?:[?#].*)?$/i);
  const extension = extensionMatch ? extensionMatch[1].toLowerCase() : "png";

  try {
    await chrome.downloads.download({
      url: clip.thumbnail,
      filename: `${baseName}.${extension}`,
      saveAs: true
    });
    setStatus("대표이미지를 저장했습니다.");
  } catch (error) {
    console.error(error);
    setStatus("이미지 저장에 실패했습니다.");
  }
}

async function loadImageElement(src) {
  return await new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = reject;
    image.src = src;
  });
}

async function cropCapturedImage(dataUrl, rect, devicePixelRatio = 1) {
  if (!rect || rect.width < 40 || rect.height < 40) {
    return dataUrl;
  }

  const sourceImage = await loadImageElement(dataUrl);
  const scale = devicePixelRatio || 1;
  const cropX = clamp(Math.round(rect.x * scale), 0, sourceImage.width - 1);
  const cropY = clamp(Math.round(rect.y * scale), 0, sourceImage.height - 1);
  const cropWidth = clamp(Math.round(rect.width * scale), 1, sourceImage.width - cropX);
  const cropHeight = clamp(Math.round(rect.height * scale), 1, sourceImage.height - cropY);

  const canvas = document.createElement("canvas");
  canvas.width = cropWidth;
  canvas.height = cropHeight;

  const context = canvas.getContext("2d");
  context.drawImage(
    sourceImage,
    cropX,
    cropY,
    cropWidth,
    cropHeight,
    0,
    0,
    cropWidth,
    cropHeight
  );

  return canvas.toDataURL("image/png");
}

function getFilteredClips() {
  const query = searchQuery.trim().toLowerCase();
  if (!query) {
    return clips;
  }

  return clips.filter((clip) => {
    const haystack = [
      clip.title,
      clip.productName,
      clip.series,
      clip.url,
      clip.source,
      clip.memo,
      clip.specSummary,
      ...(clip.detailLines || [])
    ]
      .filter(Boolean)
      .join(" ")
      .toLowerCase();

    return haystack.includes(query);
  });
}

function renderEmptyState(message) {
  const empty = document.createElement("p");
  empty.className = "empty-state";
  empty.textContent = message;
  clipList.appendChild(empty);
}

function renderDetailSummary(detailSummary, clip) {
  detailSummary.innerHTML = "";

  const lines = [];
  if (clip.series) {
    lines.push({ text: `시리즈: ${clip.series}`, strong: true });
  }
  if (clip.productName && clip.productName !== clip.title) {
    lines.push({ text: clip.productName, strong: true });
  }
  for (const line of (clip.detailLines || []).slice(0, 3)) {
    if (line) {
      lines.push({ text: line, strong: false });
    }
  }

  if (lines.length === 0) {
    detailSummary.hidden = true;
    return;
  }

  detailSummary.hidden = false;
  for (const line of lines) {
    const item = document.createElement("div");
    item.className = `clip-detail-line${line.strong ? " is-strong" : ""}`;
    item.textContent = line.text;
    detailSummary.appendChild(item);
  }
}

function renderImageSuggestions(imageSuggestions, clip) {
  imageSuggestions.innerHTML = "";

  const uniqueImages = uniqueNonEmpty(clip.imageCandidates);
  uniqueImages.slice(0, 5).forEach((candidateUrl) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = `image-suggestion${candidateUrl === clip.thumbnail ? " is-active" : ""}`;

    const preview = document.createElement("img");
    preview.src = candidateUrl;
    preview.alt = "이미지 후보";
    button.appendChild(preview);

    button.addEventListener("click", () => {
      updateClip(clip.id, { thumbnail: candidateUrl });
      setStatus("대표이미지를 변경했습니다.");
    });

    imageSuggestions.appendChild(button);
  });
}

function renderTitleSuggestions(titleSuggestions, clip) {
  titleSuggestions.innerHTML = "";

  const uniqueTitles = uniqueNonEmpty(clip.titleCandidates).filter((candidate) => candidate !== clip.title);
  uniqueTitles.slice(0, 4).forEach((candidate) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "suggestion-chip";
    button.textContent = candidate;
    button.addEventListener("click", () => {
      updateClip(clip.id, { title: candidate });
      setStatus("제목 후보를 적용했습니다.");
    });
    titleSuggestions.appendChild(button);
  });
}

function render() {
  const filteredClips = getFilteredClips();
  clipCount.textContent = `${filteredClips.length} / ${clips.length}`;
  clipList.innerHTML = "";

  if (clips.length === 0) {
    renderEmptyState("아직 저장된 링크가 없습니다.");
    return;
  }

  if (filteredClips.length === 0) {
    renderEmptyState("검색 결과가 없습니다.");
    return;
  }

  filteredClips.forEach((clip) => {
    const fragment = template.content.cloneNode(true);
    const card = fragment.querySelector(".clip-card");
    const thumb = fragment.querySelector(".clip-thumb");
    const imageSuggestions = fragment.querySelector(".image-suggestions");
    const titleInput = fragment.querySelector(".clip-title");
    const titleSuggestions = fragment.querySelector(".title-suggestions");
    const detailSummary = fragment.querySelector(".clip-detail-summary");
    const urlInput = fragment.querySelector(".clip-url");
    const memoInput = fragment.querySelector(".clip-memo");
    const sourceLabel = fragment.querySelector(".clip-source");
    const titleCopyButton = fragment.querySelector(".title-copy-button");
    const imageButton = fragment.querySelector(".image-button");
    const openButton = fragment.querySelector(".open-button");
    const copyButton = fragment.querySelector(".copy-button");
    const removeButton = fragment.querySelector(".remove-button");

    card.dataset.id = clip.id;
    thumb.src = clip.thumbnail || "";
    thumb.alt = clip.title || "클립 이미지";
    thumb.style.visibility = clip.thumbnail ? "visible" : "hidden";

    titleInput.value = clip.title || "";
    urlInput.value = clip.url || "";
    memoInput.value = clip.memo || "";
    sourceLabel.textContent = clip.source || getHostname(clip.url);

    renderImageSuggestions(imageSuggestions, clip);
    renderTitleSuggestions(titleSuggestions, clip);
    renderDetailSummary(detailSummary, clip);

    titleInput.addEventListener("input", (event) => {
      updateClip(clip.id, { title: event.target.value });
    });

    urlInput.addEventListener("input", (event) => {
      const nextUrl = event.target.value;
      updateClip(clip.id, {
        url: nextUrl,
        source: getHostname(nextUrl)
      });
    });

    memoInput.addEventListener("input", (event) => {
      updateClip(clip.id, { memo: event.target.value });
    });

    titleCopyButton.addEventListener("click", async () => {
      if (!clip.title) {
        setStatus("복사할 제목이 없습니다.");
        return;
      }

      try {
        await navigator.clipboard.writeText(clip.title);
        setStatus("제목을 복사했습니다.");
      } catch (error) {
        console.error(error);
        setStatus("제목 복사에 실패했습니다.");
      }
    });

    imageButton.addEventListener("click", async () => {
      await downloadImageForClip(clip);
    });

    openButton.addEventListener("click", async () => {
      if (!clip.url) {
        setStatus("열 수 있는 링크가 없습니다.");
        return;
      }

      await chrome.tabs.create({ url: clip.url });
    });

    copyButton.addEventListener("click", async () => {
      if (!clip.url) {
        setStatus("복사할 링크가 없습니다.");
        return;
      }

      try {
        await navigator.clipboard.writeText(clip.url);
        setStatus("링크를 복사했습니다.");
      } catch (error) {
        console.error(error);
        setStatus("링크 복사에 실패했습니다.");
      }
    });

    removeButton.addEventListener("click", () => {
      removeClip(clip.id);
    });

    clipList.appendChild(fragment);
  });
}

async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs[0];
}

function findProductCaptureRect() {
  const parseBackgroundUrl = (value) => {
    const match = (value || "").match(/url\((['"]?)(.*?)\1\)/i);
    return match?.[2] || "";
  };

  const scoreRectCandidate = ({ rect, textBlob, isBackground = false }) => {
    if (!rect || rect.width < 120 || rect.height < 120) {
      return null;
    }

    if (rect.bottom < 30 || rect.right < 30) {
      return null;
    }

    let score = rect.width * rect.height;

    if (rect.width >= 320 && rect.height >= 320) {
      score += 450000;
    }

    if (rect.top >= 0 && rect.top < window.innerHeight * 1.1) {
      score += 160000;
    }

    if (rect.left >= 0 && rect.left < window.innerWidth * 0.72) {
      score += 130000;
    }

    if (rect.left > window.innerWidth * 0.72) {
      score -= 120000;
    }

    if (isBackground) {
      score += 100000;
    }

    if (/product|goods|item|detail|gallery|hero|main|zoom|viewer|photo|image|slide/.test(textBlob)) {
      score += 220000;
    }

    if (/thumb|thumbnail|icon|logo|brand|banner|avatar|sprite|swatch|option|download|pdf|manual|instagram|youtube|kakao/.test(textBlob)) {
      score -= 320000;
    }

    return score;
  };

  const imageCandidates = Array.from(document.images || [])
    .map((img) => {
      if (img.closest("header, nav, footer, aside")) {
        return null;
      }

      const rect = img.getBoundingClientRect();
      const textBlob = [
        img.alt || "",
        img.className || "",
        img.id || "",
        img.closest("[class]")?.className || "",
        img.closest("[id]")?.id || ""
      ]
        .join(" ")
        .toLowerCase();

      const score = scoreRectCandidate({ rect, textBlob });
      if (!score) {
        return null;
      }

      return { rect, score };
    })
    .filter(Boolean);

  const backgroundCandidates = Array.from(
    document.querySelectorAll("main div, main a, main figure, main section, [role='main'] div, [role='main'] a, [role='main'] figure")
  )
    .map((node) => {
      const style = window.getComputedStyle(node);
      const backgroundUrl = parseBackgroundUrl(style.backgroundImage || "");
      if (!backgroundUrl) {
        return null;
      }

      const rect = node.getBoundingClientRect();
      const textBlob = [
        node.className || "",
        node.id || "",
        node.getAttribute("aria-label") || ""
      ]
        .join(" ")
        .toLowerCase();

      const score = scoreRectCandidate({ rect, textBlob, isBackground: true });
      if (!score) {
        return null;
      }

      return { rect, score };
    })
    .filter(Boolean);

  const best = [...imageCandidates, ...backgroundCandidates].sort((a, b) => b.score - a.score)[0];
  if (!best) {
    return null;
  }

  const margin = 12;
  return {
    x: Math.max(best.rect.left - margin, 0),
    y: Math.max(best.rect.top - margin, 0),
    width: Math.min(best.rect.width + margin * 2, window.innerWidth),
    height: Math.min(best.rect.height + margin * 2, window.innerHeight),
    devicePixelRatio: window.devicePixelRatio || 1
  };
}

async function captureProductVisualDataUrl() {
  const tab = await getActiveTab();
  if (!tab?.id || !tab.windowId) {
    return "";
  }

  const rectResult = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: findProductCaptureRect
  });

  const rect = rectResult?.[0]?.result;
  const visibleDataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, {
    format: "png"
  });

  if (!visibleDataUrl) {
    return "";
  }

  try {
    return await cropCapturedImage(visibleDataUrl, rect, rect?.devicePixelRatio || 1);
  } catch (error) {
    console.error(error);
    return visibleDataUrl;
  }
}

function scrapePage() {
  const cleanText = (value) => (value || "").replace(/\s+/g, " ").trim();

  const normalizeTextForCompare = (value) =>
    cleanText(value)
      .toLowerCase()
      .replace(/https?:\/\/|www\./g, "")
      .replace(/[^a-z0-9\uac00-\ud7a3]+/g, "");

  const uniqueNonEmpty = (values) =>
    Array.from(new Set((values || []).map((value) => cleanText(value)).filter(Boolean)));

  const getMeta = (property) =>
    document.querySelector(`meta[property="${property}"]`)?.content?.trim() ||
    document.querySelector(`meta[name="${property}"]`)?.content?.trim() ||
    "";

  const normalizeUrl = (value) => {
    if (!value) {
      return "";
    }

    try {
      return new URL(value, location.href).href;
    } catch {
      return value;
    }
  };

  const scoreVisualCandidate = ({
    src,
    rect,
    textBlob = "",
    naturalWidth = 0,
    naturalHeight = 0,
    isBackground = false
  }) => {
    if (!src || !rect || rect.width < 80 || rect.height < 80) {
      return null;
    }

    if (rect.bottom < 0 || rect.right < 0) {
      return null;
    }

    let score = rect.width * rect.height;

    if (rect.width >= 240 && rect.height >= 240) {
      score += 250000;
    }

    if (rect.left < window.innerWidth * 0.72) {
      score += 180000;
    }

    if (rect.top >= 0 && rect.top < window.innerHeight * 1.1) {
      score += 120000;
    }

    if (naturalWidth >= 600 || naturalHeight >= 600) {
      score += 80000;
    }

    if (isBackground) {
      score += 50000;
    }

    if (/product|goods|item|detail|gallery|hero|main|zoom|viewer|photo|image|slide/.test(textBlob)) {
      score += 120000;
    }

    if (/thumb|thumbnail|icon|logo|brand|banner|avatar|sprite|swatch|option|download|manual|instagram|youtube|kakao|cad|pdf/.test(textBlob)) {
      score -= 280000;
    }

    return { src: normalizeUrl(src), score };
  };

  const pickProductImages = () => {
    const imageCandidates = Array.from(document.images || [])
      .map((img) => {
        const src = normalizeUrl(img.currentSrc || img.src || "");
        const rect = img.getBoundingClientRect();
        const textBlob = [
          img.alt || "",
          img.className || "",
          img.id || "",
          img.closest("[class]")?.className || "",
          img.closest("[id]")?.id || ""
        ]
          .join(" ")
          .toLowerCase();

        if (img.closest("header, nav, footer, aside")) {
          return null;
        }

        return scoreVisualCandidate({
          src,
          rect,
          naturalWidth: img.naturalWidth || 0,
          naturalHeight: img.naturalHeight || 0,
          textBlob
        });
      })
      .filter(Boolean);

    const backgroundCandidates = Array.from(
      document.querySelectorAll("main div, main a, main figure, main section, [role='main'] div, [role='main'] a, [role='main'] figure")
    )
      .map((node) => {
        const style = window.getComputedStyle(node);
        const backgroundImage = style.backgroundImage || "";
        const match = backgroundImage.match(/url\((['"]?)(.*?)\1\)/i);
        if (!match?.[2] || backgroundImage === "none") {
          return null;
        }

        const rect = node.getBoundingClientRect();
        const textBlob = [
          node.className || "",
          node.id || "",
          node.getAttribute("aria-label") || ""
        ]
          .join(" ")
          .toLowerCase();

        return scoreVisualCandidate({
          src: normalizeUrl(match[2]),
          rect,
          textBlob,
          isBackground: true
        });
      })
      .filter(Boolean);

    const candidates = [...imageCandidates, ...backgroundCandidates].sort((a, b) => b.score - a.score);
    return Array.from(new Set(candidates.map((candidate) => candidate.src))).slice(0, 8);
  };

  const textLengthScore = (text) => {
    const length = cleanText(text).length;
    if (length < 2) {
      return 0;
    }

    if (length <= 12) {
      return 4000;
    }

    if (length <= 40) {
      return 9000;
    }

    if (length <= 80) {
      return 5000;
    }

    return 1000;
  };

  const pickBrandName = () => {
    const metaBrand =
      getMeta("product:brand") ||
      getMeta("og:site_name") ||
      document.querySelector('meta[name="application-name"]')?.content?.trim() ||
      "";

    const logoCandidate = cleanText(
      document.querySelector("header img[alt]")?.getAttribute("alt") ||
      document.querySelector(".logo")?.textContent ||
      document.querySelector("[class*='brand']")?.textContent ||
      ""
    );

    return metaBrand || logoCandidate || location.hostname.replace(/^www\./, "");
  };

  const brandName = pickBrandName();
  const brandKey = normalizeTextForCompare(brandName);

  const isLikelyNoiseText = (text) => {
    const normalized = normalizeTextForCompare(text);
    if (!normalized) {
      return true;
    }

    if (brandKey && normalized === brandKey) {
      return true;
    }

    if (/https?:|www\.|\.co\.kr|\.com|\.net|\.org/i.test(text)) {
      return true;
    }

    if (text.includes(" > ") || text.includes("|")) {
      return true;
    }

    if (/^(product|series|discover|home|main)$/i.test(text)) {
      return true;
    }

    if (/^(욕실|주방|부품 및 지원|기술 문서 검색|욕실 컬렉션|새 소식)$/i.test(text)) {
      return true;
    }

    if (/american standard korea|american standard|fontana/i.test(text) && text.length <= 30) {
      return true;
    }

    return false;
  };

  const pickProductName = () => {
    const selectors = [
      "main h1",
      "[role='main'] h1",
      ".product-title",
      ".product_name",
      ".prd-name",
      ".item-title",
      ".goods-name",
      ".detail-title",
      ".product-name",
      ".summary h1",
      "section h1",
      "article h1",
      "main h2",
      "[role='main'] h2",
      "main .title",
      "main .name",
      "main .tit",
      "main strong",
      "main p",
      "main span"
    ];

    const candidates = Array.from(document.querySelectorAll(selectors.join(",")))
      .map((node) => {
        const text = cleanText(node.textContent);
        if (!text || text.length > 120 || isLikelyNoiseText(text)) {
          return null;
        }

        const rect = node.getBoundingClientRect();
        if (rect.width < 120 || rect.height < 18) {
          return null;
        }

        if (rect.top < 0 || rect.top > window.innerHeight * 1.4) {
          return null;
        }

        if (node.closest("header, nav, footer, aside")) {
          return null;
        }

        const style = window.getComputedStyle(node);
        const fontSize = parseFloat(style.fontSize || "0");
        const fontWeight = parseInt(style.fontWeight || "400", 10);
        const normalizedText = normalizeTextForCompare(text);

        if (brandKey && normalizedText.includes(brandKey) && text.length < 28) {
          return null;
        }

        let score = textLengthScore(text);

        if (node.tagName === "H1") {
          score += 12000;
        }

        if (rect.top >= 0 && rect.top < window.innerHeight * 0.8) {
          score += 9000;
        }

        if (rect.left > window.innerWidth * 0.45) {
          score += 4500;
        }

        if (rect.left > window.innerWidth * 0.58) {
          score += 6000;
        }

        if (fontSize >= 28) {
          score += 12000;
        } else if (fontSize >= 22) {
          score += 8000;
        } else if (fontSize >= 18) {
          score += 4000;
        }

        if (fontWeight >= 500) {
          score += 2500;
        }

        if (/product|goods|item|detail|summary|info|name|title/i.test(node.className || "")) {
          score += 5000;
        }

        if (/[가-힣]/.test(text)) {
          score += 3500;
        }

        if (/[A-Z]{2,}\s*\d|[A-Z]{2,}[0-9]{2,}/.test(text)) {
          score += 2500;
        }

        if (/(하부|탱크|시트커버|도기|비데|모델|규격|품번)/.test(text)) {
          score -= 14000;
        }

        if (text.length < 4) {
          score -= 8000;
        }

        return { text, score };
      })
      .filter(Boolean)
      .sort((a, b) => b.score - a.score);

    return candidates[0]?.text || "";
  };

  const extractDetailInfo = () => {
    const mainBlocks = Array.from(document.querySelectorAll("main, [role='main'], article, section"));
    const textNodes = mainBlocks
      .flatMap((block) => Array.from(block.querySelectorAll("h1, h2, h3, h4, strong, p, li, span, dt, dd")))
      .map((node) => {
        const text = cleanText(node.textContent);
        const rect = node.getBoundingClientRect();
        const style = window.getComputedStyle(node);

        return {
          text,
          rect,
          fontSize: parseFloat(style.fontSize || "0"),
          fontWeight: parseInt(style.fontWeight || "400", 10),
          tagName: node.tagName
        };
      })
      .filter(({ text, rect }) => text && text.length <= 120 && rect.width > 90 && rect.height > 14);

    const rightSideNodes = textNodes.filter(({ rect }) =>
      rect.left > window.innerWidth * 0.55 &&
      rect.right < window.innerWidth - 10 &&
      rect.top > 80 &&
      rect.top < window.innerHeight * 1.6
    );

    const seriesCandidate = rightSideNodes
      .filter(({ text }) => {
        if (isLikelyNoiseText(text)) {
          return false;
        }

        return (
          /series|cornerstone|signature|callisto|quadro|easy lift/i.test(text) ||
          (/^[A-Z0-9\s-]{4,30}$/.test(text) && !/[가-힣]/.test(text))
        );
      })
      .sort((a, b) => a.rect.top - b.rect.top)[0];

    const headingCandidate = rightSideNodes
      .filter(({ text }) => {
        if (isLikelyNoiseText(text)) {
          return false;
        }

        if (text.length < 4 || text.length > 60) {
          return false;
        }

        return /[가-힣]/.test(text) || /[A-Z]{2,}\s*[A-Z0-9-]{1,}/.test(text);
      })
      .map((item) => {
        let score = item.fontSize * 120 + item.rect.width + item.rect.height * 12;

        if (/[가-힣]/.test(item.text)) {
          score += 4000;
        }

        if (item.tagName === "H1" || item.tagName === "H2") {
          score += 6000;
        }

        if (item.fontWeight >= 500) {
          score += 1500;
        }

        if (item.rect.top < window.innerHeight * 0.7) {
          score += 1200;
        }

        return { ...item, score };
      })
      .sort((a, b) => b.score - a.score)[0];

    const columnLeft = headingCandidate ? headingCandidate.rect.left - 40 : window.innerWidth * 0.58;
    const detailTop = headingCandidate ? headingCandidate.rect.bottom + 10 : 120;

    const detailLines = Array.from(new Set(
      rightSideNodes
        .filter(({ text, rect }) => {
          if (isLikelyNoiseText(text)) {
            return false;
          }

          if (text === headingCandidate?.text || text === seriesCandidate?.text) {
            return false;
          }

          if (rect.top < detailTop || rect.left < columnLeft) {
            return false;
          }

          if (text.length < 3 || text.length > 80) {
            return false;
          }

          return /:|\(|\)|[A-Z]{1,5}[0-9]{2,}|[가-힣]{2,}/.test(text);
        })
        .sort((a, b) => a.rect.top - b.rect.top)
        .map(({ text }) => text)
    )).slice(0, 4);

    const productLine =
      detailLines.find((line) => /[가-힣]/.test(line) && !/:/.test(line) && line.length >= 6) || "";

    return {
      series: seriesCandidate?.text || "",
      visibleProductName: headingCandidate?.text || productLine,
      detailLines: detailLines.filter((line) => line !== productLine),
      specSummary: detailLines.filter((line) => line !== productLine).slice(0, 3).join(" / ")
    };
  };

  const detailInfo = extractDetailInfo();
  const h1Text = cleanText(document.querySelector("h1")?.textContent || "");
  const ogTitle = cleanText(getMeta("og:title"));
  const documentTitle = cleanText(document.title);

  const productName =
    detailInfo.visibleProductName ||
    pickProductName() ||
    h1Text ||
    ogTitle ||
    documentTitle;

  const buildTitle = (brand, product) => {
    const cleanBrand = cleanText(brand);
    const cleanProduct = cleanText(product);

    if (cleanBrand && cleanProduct) {
      if (cleanProduct.toLowerCase().includes(cleanBrand.toLowerCase())) {
        return cleanProduct;
      }

      return `${cleanBrand} | ${cleanProduct}`;
    }

    return cleanProduct || cleanBrand || "";
  };

  const title = buildTitle(brandName, productName);
  const titleCandidates = uniqueNonEmpty([
    title,
    productName,
    buildTitle(brandName, h1Text),
    h1Text,
    buildTitle(brandName, ogTitle),
    ogTitle,
    documentTitle
  ]);

  const imageCandidates = pickProductImages();
  const image =
    imageCandidates[0] ||
    getMeta("og:image") ||
    document.querySelector('meta[name="twitter:image"]')?.content?.trim() ||
    normalizeUrl(document.querySelector("img")?.src || "") ||
    "";

  const price =
    getMeta("product:price:amount") ||
    document.querySelector('[itemprop="price"]')?.content?.trim() ||
    document.querySelector("[data-price]")?.getAttribute("data-price") ||
    "";

  const metaBrand =
    getMeta("product:brand") ||
    document.querySelector('[itemprop="brand"]')?.textContent?.trim() ||
    "";

  return {
    title,
    titleCandidates,
    brand: brandName,
    productName,
    series: detailInfo.series,
    detailLines: detailInfo.detailLines,
    specSummary: detailInfo.specSummary,
    url: location.href,
    thumbnail: image,
    imageCandidates,
    source: location.hostname.replace(/^www\./, ""),
    price,
    metaBrand
  };
}

function normalizeClip(rawClip) {
  const title = cleanText(rawClip.title) || "Untitled Reference";
  const url = cleanText(rawClip.url);
  const source = cleanText(rawClip.source) || getHostname(url);
  const memoParts = [cleanText(rawClip.metaBrand), cleanText(rawClip.price)].filter(Boolean);

  return {
    id: createId(),
    title,
    url,
    thumbnail: rawClip.thumbnail || "",
    imageCandidates: uniqueNonEmpty(
      Array.isArray(rawClip.imageCandidates)
        ? rawClip.imageCandidates
        : rawClip.thumbnail
          ? [rawClip.thumbnail]
          : []
    ),
    source,
    memo: memoParts.join(" | "),
    titleCandidates: uniqueNonEmpty(Array.isArray(rawClip.titleCandidates) ? rawClip.titleCandidates : [title]),
    series: cleanText(rawClip.series),
    productName: cleanText(rawClip.productName),
    detailLines: uniqueNonEmpty(Array.isArray(rawClip.detailLines) ? rawClip.detailLines : []),
    specSummary: cleanText(rawClip.specSummary),
    createdAt: new Date().toISOString()
  };
}

function isDuplicate(url) {
  return clips.some((clip) => clip.url === url);
}

async function clipCurrentPageData() {
  const tab = await getActiveTab();
  if (!tab?.id) {
    throw new Error("현재 탭을 찾을 수 없습니다.");
  }

  const results = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: scrapePage
  });

  return results?.[0]?.result || null;
}

async function clipCurrentTabWithCapture() {
  try {
    const pageData = await clipCurrentPageData();
    if (!pageData?.url) {
      setStatus("현재 페이지에서 정보를 읽지 못했습니다.");
      return;
    }

    const capturedVisual = await captureProductVisualDataUrl();
    if (capturedVisual) {
      pageData.thumbnail = capturedVisual;
      pageData.imageCandidates = uniqueNonEmpty([
        capturedVisual,
        ...(Array.isArray(pageData.imageCandidates) ? pageData.imageCandidates : [])
      ]);
    }

    if (isDuplicate(pageData.url)) {
      setStatus("이미 저장된 페이지입니다.");
      return;
    }

    clips = [normalizeClip(pageData), ...clips];
    await saveClips();
    render();
    setStatus("현재 페이지를 클립에 추가했습니다.");
  } catch (error) {
    console.error(error);
    setStatus("클립 중 오류가 발생했습니다.");
  }
}

async function clearAll() {
  clips = [];
  await saveClips();
  render();
  setStatus("모든 클립을 비웠습니다.");
}

clipCurrentTabButton.addEventListener("click", () => {
  void clipCurrentTabWithCapture();
});

clearAllButton.addEventListener("click", () => {
  void clearAll();
});

searchInput.addEventListener("input", (event) => {
  searchQuery = event.target.value || "";
  render();
});

void loadClips();
